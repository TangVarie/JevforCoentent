import csv,json,hashlib,sys
from pathlib import Path
from collections import Counter
from openpyxl import load_workbook
sys.path.insert(0,'/workspace/JevforCoentent')
from judge.banks import load_bank,build_questions
from judge.comments import fill_for
from scripts.backfill_comments import post_for,state_reader
P=Path(__file__).parent;H=Path('/workspace/annotation-packets/J03-health-20261013-independent-holdout');S=H/'candidate3-reference-packet'
returned=Path('/workspace/attachments/237c0bf1-8471-4ce8-a4ca-27c2d5fe42e3/40条评论判断_鼓鼓_已填写.xlsx');template=H/'给复核人员_40条中文答题包/40条评论判断_直接填写.xlsx';sample=H/'sample-unlabelled.json';dev=Path('/workspace/annotation-packets/J03-health-20261013-round2/sample-round2.json');questions=S/'逐条题面.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (P/'reference.json').exists(), 'Never overwrite a frozen reference'
w=load_workbook(returned,data_only=False,keep_links=False);o=load_workbook(template,data_only=False,keep_links=False);packet=json.loads(questions.read_text());ai=json.loads((S/'新40条参考_AI草稿待确认.json').read_text());sm=json.loads(sample.read_text());dv=json.loads(dev.read_text());bank=load_bank(Path('/workspace/JevforCoentent/banks/candidates/comment_reader_v0.5_candidate.yaml'));byid={c['comment_id']:c for c in sm['notes']};reviewer=w['先看这里']['C4'].value
assert reviewer=='鼓鼓' and w.sheetnames==o.sheetnames
assert list(w['内部对应信息'].values)==list(o['内部对应信息'].values)
assert len(packet)==len(byid)==40
qids=bank.ids();addresses=['D12','D14','D16','D18','D20','D22','D24'];cases=[];diff=[];notes=[];distributions={q:Counter() for q in qids}
for n,c in enumerate(packet,1):
 s=w[f'第{n:02d}条'];original=o[s.title];row=byid[c['comment_id']]
 for a in ['A4','A6','A7','A9','A30']:assert s[a].value==original[a].value,(n,a)
 assert state_reader(row)==c['state'] and fill_for(post_for(row))==c['fill'] and build_questions(bank,fill=c['fill'])==c['questions']
 answers={};provenance={}
 for key,a in zip(qids,addresses):
  cell=s[a];label=cell.value;criteria=c['questions'][key];allowed=['是','否'] if criteria['type']=='noul' else list(criteria['criteria'])
  assert label in allowed and cell.data_type!='f',(n,key,label)
  note=s[a.replace('D','F')].value or '';assert s[a.replace('D','F')].data_type!='f'
  answers[key]=label;provenance[key]={'kind':'returned_reviewer_label','reviewer':reviewer,'note':note};distributions[key][label]+=1
  suggestion=ai['cases'][n-1]['answers'][key]['answer']
  if label!=suggestion:diff.append({'序号':n,'comment_id':c['comment_id'],'题目':key,'评论原文':c['state']['评论原文'],'AI草稿':suggestion,'鼓鼓返回':label,'返回备注':note})
  if note:notes.append({'sequence':n,'question_id':key,'note':note})
 cases.append({'id':c['comment_id'],'state':c['state'],'fill':c['fill'],'expect':answers,'provenance':provenance,'overall_note':s['A28'].value or ''})
# Preserve the returned judgments exactly. No AI adjudication or model-answer substitution.
ref={'reference_version':'J03-holdout-returned-review-20261015-v1','sample_version':sm['sample_version'],'sample_sha256':sha(sample),'development_sample_sha256':sha(dev),'bank_version':bank.version,'bank_sha256':bank.sha256,'filled_questions_sha256':sha(questions),'review_workbook_sha256':sha(returned),'model':bank.model,'reference_ready':True,'label_decisions_final':True,'reference_scope':'single_reviewer_returned_judgments','owner_adoption_basis':'用户随完整返回表指示：已经填写完毕，由你完成这个任务；本版本保留返回原判，不改定义或自动采纳AI稿。','reference_provenance':{'kind':'single_reviewer_returned_labels','reviewer':reviewer,'reviewer_count':1,'reviewer_label_cells':280,'AI_label_overrides':0,'AI_draft_differences':len(diff),'definition_conformance_accepted':False},'human_gold_ready':False,'accepted':False,'release_accepted':False,'model_calls_before_reference_freeze':0,'definition_caveats':['返回表存在与C3明确规则不同的解释，例如品牌名本身判具体、明确剂量判无；这些先作为单人原判保留，不回改参考或题面。','品牌/通用药名/机构以及可行动信息/判断依据边界也有差异；评估仅称与返回参考一致性。'],'cases':cases}
(P/'reference.json').write_text(json.dumps(ref,ensure_ascii=False,indent=2)+'\n')
meta={k:ref[k] for k in ['reference_version','sample_version','sample_sha256','development_sample_sha256','bank_version','bank_sha256','filled_questions_sha256','review_workbook_sha256','model','reference_scope']};meta.update({'reference_sha256':sha(P/'reference.json'),'count':40,'cells':280,'labels_frozen':True,'source_workbook':returned.name,'sample_independence':{'overlapping_dev_posts':0,'overlapping_dev_comment_texts_within_project':0},'template_sha256':sha(template),'AI_draft_sha256':sha(S/'新40条参考_AI草稿待确认.json'),'AI_draft_differences':len(diff),'differences_by_question':dict(Counter(d['题目'] for d in diff)),'label_distributions':distributions,'source_context_changes':0,'invalid_or_missing_labels':0,'AI_label_overrides':0,'gold_ready':False,'release_accepted':False})
(P/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
with (P/'与AI草稿差异_92格.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(diff[0]));writer.writeheader();writer.writerows(diff)
(P/'返回备注.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
(P/'返回核验与参考说明.md').write_text('# 40条返回核验与参考版本\n\n填写人鼓鼓。原文、角色、ID映射与C3题面未变，280格均闭集合法、无缺答。与AI草稿188格相同、92格不同；全部按返回原判保存，AI覆盖0格。原Excel、AI稿和旧700格不改。\n\n本次按用户“已经填写完毕，由你完成这个任务”的委托，冻结一个单人返回判断的参考版本，便于后续结果有稳定对照。它不是双人共识或无争议金标准；题意一致性尚未被验收。\n\n需关注：第4条以产品名字为具体理由，第27条带明确剂量却判无，与C3“名字本身不算具体、规格可以具体”存在解释差异；品牌/通用药名/机构、可行动信息/判断依据等也有边界差异。这些不自动用AI覆盖，也不改C3追分。92格差异表和所有返回备注另附。后续若要裁决或重释定义，另建版本并保留本版。\n\n新40条Jev调用0；冻结此参考不表示候选或上线通过，也不扩展原C1一次调用许可。\n\n参考SHA-256：`'+meta['reference_sha256']+'`\n',encoding='utf-8')
print(json.dumps({'reference_sha256':meta['reference_sha256'],'workbook_sha256':sha(returned),'count':40,'cells':280,'differences':len(diff),'differences_by_question':meta['differences_by_question'],'source':'single_reviewer_returned_judgments','AI_overrides':0},ensure_ascii=False))
