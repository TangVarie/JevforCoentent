"""Historical v1 report reproduction only; never makes model calls or certifies v2."""
from pathlib import Path
import importlib.util,json,sys
sys.path.insert(0,'/workspace/JevforCoentent')
r=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('historical_C4_v1',r/'historical_evaluator_v1.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def never_call(*a,**kw):raise RuntimeError('Historical reconstruction forbids model client creation')
h.JevClient=never_call
sets=[('synthetic-spec20',Path('/workspace/JevforCoentent/fixtures/comment_candidate4_spec.json'),None),('development-returned40',Path('/workspace/annotation-packets/J03-health-20261013-independent-holdout/sample-unlabelled.json'),Path('/workspace/annotation-packets/J03-health-20261015-holdout-reference/reference.json')),('unseen-AI40',r/'unseen-sample.json',None)]
proof=[]
for name,sample,original in sets:
 p=r/name
 code=h.evaluate(sample=sample,reference=p/'reference.json',protocol=p/'protocol.json',output=p/'historical-v1-replay',source_reference=original,resume=p/'live-once/checkpoint.json')
 a=json.loads((p/'live-once/summary.json').read_text());b=json.loads((p/'historical-v1-replay/summary.json').read_text())
 for k in ('binding','per_question','endorsement_boundary','diagnostic_gate','answer_agreement_cells','ambiguous_cells','invalid_or_missing_cells'):assert a[k]==b[k],(name,k)
 assert b['model_calls_this_run']==0
 proof.append({'scope':name,'all_metrics_identical':True,'new_model_calls':0,'strict_v2_probability_acceptance':False,'historical_snapshot_only':True,'exit':code})
(r/'historical-v1-reconstruction-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print('3 historical v1 reports reproduced with model-client creation forbidden; not upgraded to v2.')
